########################################
#                                      #
#  PRÁCE S DATY MEZINÁRODNÍCH ŠETŘENÍ  #
#                                      #
########################################

# Aleš Macháček
# 1.12.2025
# Aplikace kvantitativních metod

library(dplyr)

# NEZAPOMÍNÁME NASTAVIT WORKING DIRECTORY

load("PISA_2022_Merge.Rdata")

########################################################
# 1. Základní vážené operace ve srovnávacích šetřeních #
########################################################

###1. Vážený průměr
  
#Vážený průměr indexu šikany BULLIED
weighted.mean(PISA_2022_Merge$BULLIED, PISA_2022_Merge$W_FSTUWT)

#Vážený průměr skóre z matematiky PV1MATH (POZOR!! Výsledek pouze z jedné plausibilní hodnoty = není to přesná hodnota)
weighted.mean(PISA_2022_Merge$PV1MATH, PISA_2022_Merge$W_FSTUWT)

###2. Regresní model se všemi plausibilními hodnotami a váhou

#Ideální je použít IDB analyser
#Nebo balíček EdSurvey (viz níže)
#Často ale chceme prostě jen pracovat v R bez nutnosti stahovat celou databázi PISA/PIRLS atd
#Či máme nějaké specifické upravené/napárované data
#V tomto případě v současnosti nejlepší volba custom balíček mixPV

install.packages("WeMix")

library(WeMix)
source("https://raw.githubusercontent.com/flh3/pubdata/main/mixPV/mixPV.R")

Zakladni_model <- mixPV(PV1MATH + PV2MATH + PV3MATH + PV4MATH + PV5MATH + PV6MATH + PV7MATH + PV8MATH + PV9MATH + PV10MATH ~
                             ESCS +
                             ST004D01T + (1|CNTSCHID), 
                           weights = c("W_FSTUWT", "W_SCHGRNRABWT"),
                           data = PISA_2022_Merge)

summary(Zakladni_model)

###############
# 2. Edsurvey #
###############

install.packages("EdSurvey")
library(EdSurvey)

#Klasická forma načtení pokud máme staženou celou velkou složku mezinárodní databáze všech států

PISA_2022_CZ <- readPISA(path = "C:/Users/alesm/Downloads/STU_QQQ_SPSS", # Cesta ke složce kam se stáhnou data
                         database = "INT",      # Mezinárodní databáze
                         countries = "cze")    # Pouze ČR (případně dopsat jaké státy chceme)


  #Pokud bychom chtěli do toho načítat další napárované proměnné
  #Například ty které vkládá ČŠI jako např. "Kraj"
  #Museli bychom použít funkci merge() v rámci Edsurvey


