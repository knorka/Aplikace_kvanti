########################################
#                                      #
#  PRÁCE S DATY MEZINÁRODNÍCH ŠETŘENÍ  #
#                                      #
########################################

# Aleš Macháček
# 1.12.2025
# Aplikace kvantitativních metod

library(dplyr)

# NEZAPOMÍNÁME NASTAVIT WORKING DIRECTORY

############
# 1. Merge #
############

# Načtení RData souborů
load("PISA_2022_MRS_SKOLY.Rdata")
load("PISA_2022_MRS_ZACI.Rdata")

# Zkrácené aliasy (jen pro pohodlí)
skoly <- PISA_2022_MRS_SKOLY
zaci  <- PISA_2022_MRS_ZACI

##################################################################################################
## Toto je jen krok bokem kdy pomocí takovýchto příkazů
## Můžeme zkontrolovat jestli všechny identifikátory jsou opravdu jen jednou v datasetu
## Většinou vpohodě ale předejdete tímto případnému bolehlavu při jakémkoliv mergování

# Počet všech škol
nrow(skoly)

# Počet jedinečných CNTSCHID
length(unique(skoly$CNTSCHID))

# Počty řádků sedí s unikátním počtem hodnot! Perfektní
##################################################################################################

#Zjistíme, které proměnné jsou v datasetech společné
#Identifikací předejdeme situaci, kdy se nám mohou ty proměnné ve výsledném datasetu zduplikovat
#Může nastat situace kdy budeme mít např. "Promenna1.x" a "Promenna1.y" = zbytečná duplikace stejné proměnné

common_vars <- intersect(names(zaci), names(skoly))
common_vars
# společné proměnné MIMO klíčovou identifikační proměnnou (CNTSCHID) = přiřazujeme každému žákovi informaci o škole na kterou chodí
common_nonkeys <- setdiff(common_vars, c("CNTSCHID"))
common_nonkeys

# ze škol vyhodíme společné ne-klíčové proměnné
skoly_for_join <- skoly %>%
  select(-all_of(common_nonkeys))

# spojení žáků se školami
PISA_2022_Merge <- zaci %>%
  left_join(skoly_for_join, by = "CNTSCHID")

# Vyexportujeme finální spojený dataset jako nový samostatný soubor
save(PISA_2022_Merge, file = "PISA_2022_Merge.RData")



